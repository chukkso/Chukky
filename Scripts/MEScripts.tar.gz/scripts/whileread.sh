I am Blessed
so are you
how are you
this is your day
how are you doing
